import requests
from bs4 import BeautifulSoup
html = requests.get("https://www.accuweather.com")
data = html.text
soup = BeautifulSoup(data,'html.parser')

tag = soup.find("div",class_="hourly-card-subcontaint")
weather = tag.find("h2")
date = weather.find("span")
print(date)
temperature = tag.find("div",class_ = "temp metric")
print(temperature)