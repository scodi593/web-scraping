import pandas as pd
# index_col="date")
workdata = pd.read_csv(r"C:\Users\Mohammed\Desktop\web-scraping\data.csv",
                       names=["duration", "date", "pulse", "max_pulse", "calories"])
print(type(workdata))
# print(workdata.iloc[0:2])#for default
# print(workdata.loc['\'2022/12/01\''])
# print(workdata.head(5))
# print(workdata.tail(5))
# print(workdata.dtypes)
# print(workdata.info())
# workdata = workdata.dropna()
avgcal = workdata['calories'].mean()
workdata['calories'].fillna(avgcal, inplace=True)
g = pd.to_datetime(workdata['date'])
workdata['date'] = g
print(workdata)
print(g)
print(workdata.dtypes)
workdata.loc(21, "calorie")
