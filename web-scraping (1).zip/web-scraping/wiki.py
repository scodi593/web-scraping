import bs4
import urllib.request
from urllib.request import urlopen
from bs4 import BeautifulSoup as soup
import csv

html = urlopen('https://en.wikipedia.org/wiki/List_of_largest_recorded_music_markets')
bsobj = soup(html.read(),"html.parser")
tbody = bsobj('table', {'class':'wikitable plainrowheaders sortable'})[2].findAll('tr')
xl = []

with open('music.csv', 'w', newline = '') as f:
    music = csv.writer(f)
    for row in tbody:
        cols = row.findChildren(recursive = False)
        cols = [element.text.strip() for element in cols]
        music.writerow(cols)
        xl.append(cols)
        print(cols)

import pandas as pd
df = pd.DataFrame(data = xl[1:], columns = xl[0])
df
df.to_excel('world_music.xlsx', index=False, header = False)
print('spreadsheet saved')