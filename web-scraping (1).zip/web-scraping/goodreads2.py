import requests
from bs4 import BeautifulSoup
import pandas as pd

page = requests.get("https://www.goodreads.com/quotes")
soup = BeautifulSoup(page.text, "html.parser")
quotes_list = soup.find("div", class_ = "quotes")
quotes = quotes_list.find_all("div", class_ = "quoteText")
tags = quotes_list.find_all("div", class_ = "quoteFooter")
quotations = {"Author":[], "Quote":[], "Tags":[]}
for quote in quotes:
    req_tags = list(tags)[0].text.replace('\n', '').strip().replace("\t", "")
    author = quote.find("span")
    temp = quote.text
    words = temp[temp.find('“'):temp.find('”')+1]
    quotations["Author"].append(author.text.strip().replace(",", ""))
    quotations["Quote"].append(words)
    quotations["Tags"].append(req_tags[11:170])
data = pd.DataFrame(quotations)
data.to_excel("goodreads.xlsx")